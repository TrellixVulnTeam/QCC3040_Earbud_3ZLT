#include <led.h>
#include <pio_common.h>

#include "aul_private.h"
#include "aul_common.h"
#include "aul_pwm.h"

#include "aul_debug.h"


/*
	QCC3040 module and DK board LED pin configure

	DK        Module
------------------------------------------
	LD1 ----- LED0 -> Used in ref app
	LD2 ----- LED1 -> Available
	LD3 ----- LED3 -> Available
	LD4 ----- Not connected
*/
#define AUL_PWM_CH0							LED_1	
#define AUL_PWM_CH1							LED_2

#define AUL_PWM_CH0_PERIOD					1
#define AUL_PWM_CH1_PERIOD					1

#define AUL_PWM_DUTY_RATIO(param)			(((100 - param) * 0xFFF) /100)


void aulPwm_init(void)
{

}

void aul_msg_pwm_start_handle(void)
{
	bool rslt;

    rslt = LedConfigure(AUL_PWM_CH0, LED_PIN_DRIVE_CONFIG, 0);
	AUL_DEBUG_PRINT("01 rslt = %d", rslt);
    rslt = LedConfigure(AUL_PWM_CH0, LED_PERIOD, AUL_PWM_CH0_PERIOD);
	AUL_DEBUG_PRINT("02 rslt = %d", rslt);
	rslt = LedConfigure(AUL_PWM_CH0, LED_DUTY_CYCLE, AUL_PWM_DUTY_RATIO(30));
	AUL_DEBUG_PRINT("03 rslt = %d", rslt);

    rslt = LedConfigure(AUL_PWM_CH1, LED_PIN_DRIVE_CONFIG, 0);
	AUL_DEBUG_PRINT("04 rslt = %d", rslt);
    rslt = LedConfigure(AUL_PWM_CH1, LED_PERIOD, AUL_PWM_CH1_PERIOD);
	AUL_DEBUG_PRINT("05 rslt = %d", rslt);
	rslt = LedConfigure(AUL_PWM_CH1, LED_DUTY_CYCLE, AUL_PWM_DUTY_RATIO(70));
	AUL_DEBUG_PRINT("06 rslt = %d", rslt);


	rslt = LedConfigure(AUL_PWM_CH0, LED_ENABLE, 1);
	AUL_DEBUG_PRINT("30 rslt = %d", rslt);
	aul_delayTime(110, FALSE);
	rslt = LedConfigure(AUL_PWM_CH1, LED_ENABLE, 1);
	AUL_DEBUG_PRINT("31 rslt = %d", rslt);

}

