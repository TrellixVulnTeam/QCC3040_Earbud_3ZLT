############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################

class HasResetTransaction(object):
    """
    Trivial mixin class that flags that a chip supports the reset
    transaction on the Hydra transaction bridge.
    """
