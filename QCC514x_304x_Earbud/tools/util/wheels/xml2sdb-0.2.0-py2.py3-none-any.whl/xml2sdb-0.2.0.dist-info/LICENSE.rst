Copyright (c) 2017, Barry Byford
All rights reserved.

QUALCOMM_COPYRIGHT_STATEMENT
