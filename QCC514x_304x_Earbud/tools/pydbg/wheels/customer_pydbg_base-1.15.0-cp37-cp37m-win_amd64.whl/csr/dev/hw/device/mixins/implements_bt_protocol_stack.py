############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2019-2020 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################

class ImplementsBTProtocolStack(object): #pylint: disable=too-few-public-methods
    """
    A mixin for a device that's running a Bluetooth stack and may have to do
    cross-subcomponent analysis.
    """
