############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2012 - 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""\
Device H/W & F/W Meta-data interfaces & implementations for CSR DDF.
"""