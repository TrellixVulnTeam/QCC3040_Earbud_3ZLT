############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2013 - 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""\
Adaptors for model.interface

Present device debugging models.

The Adaptor in Model-Adaptor-View.

Although developed for the device debugging framework these should be
application agnostic.
"""