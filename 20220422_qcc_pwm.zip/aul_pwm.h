#ifndef	AUL_PWM_H

#define AUL_PWM_H

void aulPwm_init(void);

void aul_msg_pwm_start_handle(void);

#endif	/* AUL_PWM_H */

